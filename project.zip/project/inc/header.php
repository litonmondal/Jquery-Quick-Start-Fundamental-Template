<?php
$fonts = "verdana";
$bgcolor = "#444";
$fontcolor = "#fff";
?>
<!DOCTYPE HTML>
<head>
	<title>Jquery Class</title>
<style>
	 body{font-family:<?php echo $fonts; ?>}.phpcoding{width:900px; margin:0 auto; background:<?php echo "#ddd"?>;}
	.headeroption, .footeroption{background:<?php echo $bgcolor; ?>;color:<?php echo $fontcolor; ?>;text-align:center;padding:20px;}
	.headeroption h2, .footeroption h2{margin:0;font-size:24px;}
	.maincontent{min-height:450px;font-size:18px;margin:15px;}
	.paragrap{width:815px;height:300px;border:1px solid #999;background-color:#fff;margin-top:10px;padding:26px;position:absolute;}
	.inside{width:200px;height:200px;border-radius:50%;background:#444;position:relative;}
	.addclass{width:500px;height:200px;background:red;color:#fff;font-size:30px;}
</style>
<script type="text/javascript" src="js/jquery-3.3.1.min.js"></script>
</head>
<body>
	<div class="phpcoding">
		<section class="headeroption">
			<h2><?php echo "JQuery Class"; ?></h2>		
		</section>
			<section class="maincontent">
				<hr><?php echo "Today We Are Learn That: "; ?><hr>