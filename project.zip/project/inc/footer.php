</section>
	<section class="footeroption">
		<h2><?php echo "www.theweaverrit.com"; ?></h2>
	</section>
</div>
</body>
</html>